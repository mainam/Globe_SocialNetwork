package com.isoftglobe.socialnetwork.constants;

/**
 * Created by MaiNam on 3/13/2017.
 */

public class Constants {
    public static final String DEVICE_ID = "DEVICE_ID";
}
