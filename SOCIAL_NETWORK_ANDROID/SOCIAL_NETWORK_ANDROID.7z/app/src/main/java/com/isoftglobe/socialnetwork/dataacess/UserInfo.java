package com.isoftglobe.socialnetwork.dataacess;

/**
 * Created by admin on 3/9/2017.
 */

public class UserInfo {
}
